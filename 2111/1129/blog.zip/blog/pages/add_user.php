<form action="pages/add_user_bd.php" method="post">
    <h2>Novo usuário</h2>
    <div>
        <label for="nome">Nome</label>
        <input type="text" name="nome" id="nome">
    </div>
    <div>
        <label for="email">E-mail</label>
        <input type="email" name="email" id="email">
    </div>
    <div>
        <label for="senha">Senha</label>
        <input type="password" name="senha" id="senha">
    </div>
    <div>
        <input type="submit" value="Registrar">
    </div>
</form>